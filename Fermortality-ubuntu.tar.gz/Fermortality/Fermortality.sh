#!/bin/bash
LD_PRELOAD="$(readlink -m libglfw.so.3)" ./Fermortality
